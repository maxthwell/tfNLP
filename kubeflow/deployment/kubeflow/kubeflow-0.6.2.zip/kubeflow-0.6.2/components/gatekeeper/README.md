## Http basic Auth for Kubeflow

### To build image

make build

### Prerequisites

golang to 1.11.2

```sh
$ ☞  go version
go version go1.11.2 darwin/amd64
```
