export const environment = {
  production: true,
  apiUrl: "/jupyter",
  resource: "notebooks",
  form: "/volumes/new",
  ui: "default"
};
